const socket = io('http://localhost:3000');

const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

putWallsAround(0, 0, canvas.clientWidth, canvas.clientHeight);
let startX = 40+Math.random()*560;
let startY = 40+Math.random()*400;
let playerBall = new Ball(startX, startY, 40, 5);
playerBall.player = true;
playerBall.maxSpeed =5;

//socket.on('serverToClient',(data) =>{
//    alert(data);
//})
socket.emit('clientToServer', "Hello, client!");

//quando clicchi il button, il client invia messaggio al server
HelloBtn.addEventListener('click', () => {
    socket.emit('clientToClinet', "Hello");
})

function gameLogic(){
    socket.emit('update', {x} playerBall.pos.x, y: p)ayerBall.pos.y
;}

userInput(playerBall);
requestAnimationFrame(mainLoop);