
const ws = require('nodejs-websocket')
const PORT = 8000

var numPersonConn = 0;//numero di persone connesse

//creare un server
const server = ws.createServer(connect => {

    console.log("c'è qualcuno connesso")
    numPersonConn++;//tot persone connesse +1
    connect.userName = "user" + numPersonConn;//nome utente

    //1.comunicazione broadcast a tutti che c'è qlcn connessoù
    broadcast(connect.userName + " è connesso");

    //2.riceve i dati dal browser (client)
    connect.on('text', data => {
        broadcast(data)
    })

    //3.quando c'è qlcn disconnette
    connect.on('close', data => {
        console.log("disconnessa")
        numPersonConn--;//tot persone connesse -1
        broadcast(connect.userName + " è disconnessa")
    })

    //4.quando ci sono i errori
    connect.on('error', data => {
        console.log("errore")
    })
})

//broadcast: mandare messaggi a tutti gli utenti
function broadcast(msg) {

    //server.connections: tutti gli utenti connessi
    server.connections.forEach(item => {
        item.send(msg)//mandare a ogni utente il messaggio ricevuto(msg)
    })
}

//ascoltare la porta 8000
server.listen(PORT, ()=> {
    console.log("websocket server acceso e ascolta sulla porta " + PORT);
})

